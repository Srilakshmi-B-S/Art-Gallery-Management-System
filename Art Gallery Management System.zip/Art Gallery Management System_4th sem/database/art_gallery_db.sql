create database art_gallery9;
use art_gallery9;

-- Database: `art_gallery_db`

-- Table structure for table `arts`
CREATE TABLE `arts` (
  `id` int(30) NOT NULL,
  `artist_id` int(30) NOT NULL,
  `art_title` text NOT NULL,
  `art_description` text NOT NULL,
  `status` tinyint(1) DEFAULT 0 COMMENT '0=unpublished,1=published'
);

-- Dumping data for table `arts`
INSERT INTO `arts` (`id`, `artist_id`, `art_title`, `art_description`, `status`) VALUES
(15, 2, 'Sample Art 1', 'Beautiful', 1),
(16, 3, 'Sample Art 2', 'Amazing', 1),
(17, 4, 'Sample Art 3', 'MindBlowing', 1),
(18, 5, 'Sample Art 4', 'Intresting', 1),
(19, 6, 'Sample Art 5', 'PicturePerfect', 1);

-- Table structure for table `arts_fs`
CREATE TABLE `arts_fs` (
  `id` int(30) NOT NULL,
  `art_id` text NOT NULL,
  `price` float NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=onhand,1= sold',
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
);

-- Dumping data for table `arts_fs`
INSERT INTO `arts_fs` (`id`, `art_id`, `price`, `status`, `date_created`) VALUES
(7, '15', 25000, 1, '2020-10-09 13:27:45'),
(8, '16', 50000, 0, '2020-10-09 13:47:04'),
(9, '17', 75000, 1, '2020-10-09 13:47:04'),
(10, '18', 100000, 0, '2020-10-09 13:47:04'),
(11, '19', 150000, 1, '2020-10-09 13:47:04');

-- Table structure for table `events`
CREATE TABLE `events` (
  `id` int(30) NOT NULL,
  `title` text NOT NULL,
  `artist_id` int(30) NOT NULL,
  `content` text NOT NULL,
  `event_datetime` datetime NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
);

-- Dumping data for table `events`
INSERT INTO `events` (`id`, `title`, `artist_id`, `content`, `event_datetime`, `date_created`) VALUES
(1, 'Artworks', 2, 'Beautiful', '2020-10-12 15:00:00', '2020-10-09 14:27:27'),
(2, 'Artworks', 3, 'Amazing', '2020-10-12 15:00:00', '2020-10-09 14:27:27'),
(3, 'Artworks', 4, 'MindBlowing', '2020-10-12 15:00:00', '2020-10-09 14:27:27'),
(4, 'Artworks', 5, 'PicturePerfect', '2020-10-12 15:00:00', '2020-10-09 14:27:27'),
(5, 'Artworks', 6, 'Intresting', '2020-10-12 15:00:00', '2020-10-09 14:27:27');

-- Table structure for table `orders`
CREATE TABLE `orders` (
  `id` int(30) NOT NULL,
  `art_fs_id` int(30) NOT NULL,
  `customer_id` int(30) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=for verification,1= confirmed,2 = cancel, 3= delivered',
  `deliver_schedule` date NOT NULL
);

-- Dumping data for table `orders`
INSERT INTO `orders` (`id`, `art_fs_id`, `customer_id`, `status`, `deliver_schedule`) VALUES
(1, 8, 10, 3, '2020-10-13');

-- Table structure for table `system_settings`
CREATE TABLE `system_settings` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(200) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `cover_img` text NOT NULL,
  `about_content` text NOT NULL
);

-- Dumping data for table `system_settings`
INSERT INTO `system_settings` (`id`, `name`, `email`, `contact`, `cover_img`, `about_content`) VALUES
(1, 'Art Gallery', 'artgallery@gmail.com', '1234-567-890', 'bg.jpeg', 'Welcome');

-- Table structure for table `users
CREATE TABLE `users` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `address` text NOT NULL,
  `contact` varchar(50) NOT NULL,
  `user_type` tinyint(1) NOT NULL DEFAULT 3 COMMENT '1 = admin, 2= artist,3= customers',
  `username` text NOT NULL,
  `password` text NOT NULL
);

-- Dumping data for table `users`
INSERT INTO `users` (`id`, `name`, `address`, `contact`, `user_type`, `username`, `password`) VALUES
(1, 'Administrator', 'Bengaluru', '2345671890', 1, 'admin', '0192023a7bbd73250516f069df18b500'),
(2, 'John Smith', 'Chennai', '1846-5455-55', 2, '', ''),
(3, 'George Wilson', 'Goa', '4526-5455-44', 2, '', ''),
(4, 'Mohan Das' , 'Kerala', '1234532665', 2, '', ''),
(10, 'Sanjana', 'Bengaluru', '134-672-3545', 3, '', '');

-- Indexes for table `arts`
ALTER TABLE `arts`
  ADD PRIMARY KEY (`id`);

-- Indexes for table `arts_fs`
ALTER TABLE `arts_fs`
  ADD PRIMARY KEY (`id`);

-- Indexes for table `events`
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

-- Indexes for table `orders`
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

-- Indexes for table `system_settings`
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`);

-- Indexes for table `users`
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

Select * from arts;
Select * from arts_fs;
select * from events;
select * from orders;
select * from system_settings;
select * from users;

-- Queries

-- Retrieve all published artworks along with their artists names:
Create view Table1 as 
SELECT a.art_title, a.art_description, u.name AS artist_name
FROM arts a
INNER JOIN users u ON a.artist_id = u.id
WHERE a.status = 1;
select * from Table1;

-- Find the total number of artworks sold and their total sales amount:
SELECT COUNT(*) AS total_sold_artworks, SUM(price) AS total_sales_amount
FROM arts_fs
WHERE status = 1;

-- List all events along with the artist names and scheduled date and time:
SELECT e.title AS event_title, u.name AS artist_name, e.event_datetime
FROM events e
INNER JOIN users u ON e.artist_id = u.id;

-- Retrieve the order details along with the customer's name and delivery schedule:
SELECT o.id AS order_id, u.name AS customer_name, a.art_title, af.price, o.deliver_schedule
FROM orders o
INNER JOIN users u ON o.customer_id = u.id
INNER JOIN arts_fs af ON o.art_fs_id = af.id
INNER JOIN arts a ON af.art_id = a.id;

-- Find the average price of artworks:
SELECT AVG(price) AS average_price
FROM arts_fs;

-- Calculate the total number of orders:
SELECT COUNT(*) AS total_orders
FROM orders;

-- Select the average number of artworks per artist:
SELECT AVG(artworks_per_artist) AS avg_artworks_per_artist
FROM (
    SELECT artist_id, COUNT(*) AS artworks_per_artist
    FROM arts
    GROUP BY artist_id
) AS artist_artworks;

 -- find customers who have placed orders:
SELECT DISTINCT name AS customer_name
FROM users
WHERE id IN (SELECT DISTINCT customer_id FROM orders);

