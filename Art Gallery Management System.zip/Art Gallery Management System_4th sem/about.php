 <head>
    <style>
        .description {
            text-align: center;
            justify-content: center;
            font-size: 130%;
        }
        
    </style>
</head>
 <!-- Masthead-->
        <header class="masthead">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-10 align-self-end mb-4" style="background: #0000002e;">
                    	 <h1 class="text-uppercase text-white font-weight-bold">About Us</h1>
                        <hr class="divider my-4" />
                    </div>
                    
                </div>
            </div>
        </header>

    <section class="page-section">
        <div class="container">
        <p class="description">Step into a treasure trove of creativity at our art gallery, 
        where a diverse collection of artworks awaits you. 
        Whether you're drawn to the captivating colors of a landscape painting, 
        the lifelike detail of a portrait, or the thought-provoking concept of a contemporary piece, 
        we offer a variety of artistic expressions to ignite your imagination. 
        Each piece is curated with care, representing the unique vision of talented artists. 
        Not only can you immerse yourself in the beauty of art, but you can also become its proud owner. 
        We encourage you to explore, discover, and take home a piece that resonates with you, 
        transforming your space into a reflection of your own personal style and appreciation for art.</p>      
        </div>
        </section>